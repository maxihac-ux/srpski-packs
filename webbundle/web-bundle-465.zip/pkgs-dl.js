/**
 * pkgs-dl.js — v2.24.0: менеджер подключаемых пакетов (стриминг + resume).
 *
 * Слова (JSON) вшиты в APK всегда; пакеты доставляют только ОЗВУЧКУ и модели.
 * Загрузка: raw.githubusercontent.com/maxihac-ux/srpski-packs (публичный репо,
 * CORS *, Range 206) → проверка sha256 → распаковка ZIP (STORE) → IndexedDB.
 * Аудио отдаётся через Service Worker /sw.js по путям /__pkg/<pack>/<file>,
 * резолвер приложения подхватывает их через хук window.__pkgAudio.
 *
 * Новое в v2.24.0 (по бэклогу аудита):
 *  - память: zip больше НЕ собирается в JS-куче целиком. Чанки потока вливаются
 *    в Blob (браузерное хранилище), SHA-256 считается инкрементально на лету,
 *    распаковка читает из Blob по одному файлу (slice) — пик памяти ≈ 1× zip
 *    вместо прежних ~3× (chunks-массив + arrayBuffer ×2).
 *  - докачка (Range-resume): обрыв/пауза сохраняют частичный Blob + состояние
 *    хеша в IndexedDB «srpski-packs-parts»; повторный запуск продолжает с байта
 *    got (сервер отвечает 206; при 200/416/несовпадении позиции — старт с нуля).
 *  - отмена: AbortController — PKGDL.pause(id) (пауза, часть сохраняется) и
 *    PKGDL.cancel(id) (отмена, часть удаляется).
 *  - серверный манифест с версионированием: packs/manifest.json из репо паков
 *    (version/packsRepoVer) мерджится с встроенным на init; расхождение sha256
 *    установленного пакета и манифеста = состояние «update».
 *  - navigator.storage.persist() — постоянное хранилище для IndexedDB паков.
 *
 * Состояния пакета (p.audio):
 *   baked | remote | update | downloading(pct) | paused(pct) | unpacking | downloaded.
 * API: window.PKGDL.{init,augment,download,pause,cancel,remove,snapshot,states}
 * Событие "pkgs-changed" — совместимо с карточкой пакетов в настройках.
 */
(function () {
  "use strict";
  var DEFAULT_BASE = "https://raw.githubusercontent.com/maxihac-ux/srpski-packs/main/packs/";
  var MIRROR_BASE = "https://cdn.jsdelivr.net/gh/maxihac-ux/srpski-packs@main/packs/";
  function base() {
    try { return localStorage.getItem("pkgs_mirror") || DEFAULT_BASE; } catch (e) { return DEFAULT_BASE; }
  }
  var MIME = {
    ".ogg": "audio/ogg", ".json": "application/json", ".mjs": "text/javascript",
    ".wasm": "application/wasm", ".txt": "text/plain", ".onnx": "application/octet-stream",
  };
  function mimeOf(name) {
    var i = name.lastIndexOf(".");
    return (i >= 0 && MIME[name.slice(i)]) || "application/octet-stream";
  }

  // ---------- IndexedDB (пакеты — как в sw.js, версия не меняется) ----------
  var DBP = null;
  function db() {
    if (DBP) return DBP;
    DBP = new Promise(function (res, rej) {
      var rq = indexedDB.open("srpski-packs", 1);
      rq.onupgradeneeded = function () {
        var d = rq.result;
        if (!d.objectStoreNames.contains("blobs")) d.createObjectStore("blobs");
        if (!d.objectStoreNames.contains("packs")) d.createObjectStore("packs");
      };
      rq.onsuccess = function () { res(rq.result); };
      rq.onerror = function () { rej(rq.error); };
    });
    return DBP;
  }
  // Отдельная БД для частичных загрузок: не поднимаем версию основной,
  // чтобы Service Worker (соединение версии 1) не блокировал миграцию.
  var DBP2 = null;
  function dbParts() {
    if (DBP2) return DBP2;
    DBP2 = new Promise(function (res, rej) {
      var rq = indexedDB.open("srpski-packs-parts", 1);
      rq.onupgradeneeded = function () {
        var d = rq.result;
        if (!d.objectStoreNames.contains("parts")) d.createObjectStore("parts");
      };
      rq.onsuccess = function () { res(rq.result); };
      rq.onerror = function () { rej(rq.error); };
    });
    return DBP2;
  }
  function idbReq(dbp, store, mode, fn) {
    return dbp.then(function (d) {
      return new Promise(function (res, rej) {
        var t = d.transaction(store, mode), rq = fn(t.objectStore(store));
        rq.onsuccess = function () { res(rq.result); };
        rq.onerror = function () { rej(rq.error); };
      });
    });
  }
  function bGet(store, key) { return idbReq(db(), store, "readonly", function (s) { return s.get(key); }); }
  function bSet(store, key, val) { return idbReq(db(), store, "readwrite", function (s) { return s.put(val, key); }); }
  function bDel(store, key) { return idbReq(db(), store, "readwrite", function (s) { return s.delete(key); }); }
  function bKeys(store) { return idbReq(db(), store, "readonly", function (s) { return s.getAllKeys(); }); }
  function pGet(key) { return idbReq(dbParts(), "parts", "readonly", function (s) { return s.get(key); }); }
  function pSet(key, val) { return idbReq(dbParts(), "parts", "readwrite", function (s) { return s.put(val, key); }); }
  function pDel(key) { return idbReq(dbParts(), "parts", "readwrite", function (s) { return s.delete(key); }); }

  // -- sha256:begin (инкрементальный SHA-256; состояние сериализуется для resume)
  var K256 = [
    0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5, 0x3956c25b, 0x59f111f1, 0x923f82a4, 0xab1c5ed5,
    0xd807aa98, 0x12835b01, 0x243185be, 0x550c7dc3, 0x72be5d74, 0x80deb1fe, 0x9bdc06a7, 0xc19bf174,
    0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc, 0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da,
    0x983e5152, 0xa831c66d, 0xb00327c8, 0xbf597fc7, 0xc6e00bf3, 0xd5a79147, 0x06ca6351, 0x14292967,
    0x27b70a85, 0x2e1b2138, 0x4d2c6dfc, 0x53380d13, 0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85,
    0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3, 0xd192e819, 0xd6990624, 0xf40e3585, 0x106aa070,
    0x19a4c116, 0x1e376c08, 0x2748774c, 0x34b0bcb5, 0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f, 0x682e6ff3,
    0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208, 0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2];
  function rotr(x, n) { return (x >>> n) | (x << (32 - n)); }
  function Sha256() {
    this.H = [0x6a09e667, 0xbb67ae85, 0x3c6ef372, 0xa54ff53a, 0x510e527f, 0x9b05688c, 0x1f83d9ab, 0x5be0cd19];
    this.buf = new Uint8Array(64);
    this.bl = 0;
    this.len = 0;
  }
  Sha256.prototype._block = function (p, off) {
    var w = new Int32Array(64), i, H = this.H;
    for (i = 0; i < 16; i++)
      w[i] = (p[off + i * 4] << 24) | (p[off + i * 4 + 1] << 16) | (p[off + i * 4 + 2] << 8) | p[off + i * 4 + 3];
    for (i = 16; i < 64; i++) {
      var a15 = w[i - 15], a2 = w[i - 2];
      var s0 = rotr(a15, 7) ^ rotr(a15, 18) ^ (a15 >>> 3);
      var s1 = rotr(a2, 17) ^ rotr(a2, 19) ^ (a2 >>> 10);
      w[i] = (w[i - 16] + s0 + w[i - 7] + s1) | 0;
    }
    var a = H[0], b = H[1], c = H[2], d = H[3], e = H[4], f = H[5], g = H[6], h = H[7];
    for (i = 0; i < 64; i++) {
      var S1 = rotr(e, 6) ^ rotr(e, 11) ^ rotr(e, 25);
      var ch = (e & f) ^ (~e & g);
      var T1 = (h + S1 + ch + K256[i] + w[i]) | 0;
      var S0 = rotr(a, 2) ^ rotr(a, 13) ^ rotr(a, 22);
      var mj = (a & b) ^ (a & c) ^ (b & c);
      var T2 = (S0 + mj) | 0;
      h = g; g = f; f = e; e = (d + T1) | 0; d = c; c = b; b = a; a = (T1 + T2) | 0;
    }
    H[0] = (H[0] + a) | 0; H[1] = (H[1] + b) | 0; H[2] = (H[2] + c) | 0; H[3] = (H[3] + d) | 0;
    H[4] = (H[4] + e) | 0; H[5] = (H[5] + f) | 0; H[6] = (H[6] + g) | 0; H[7] = (H[7] + h) | 0;
  };
  Sha256.prototype.update = function (u8) {
    this.len += u8.byteLength;
    var n = u8.byteLength, i = 0;
    if (this.bl > 0) {
      var take = Math.min(64 - this.bl, n);
      this.buf.set(u8.subarray(0, take), this.bl);
      this.bl += take; i = take;
      if (this.bl === 64) { this._block(this.buf, 0); this.bl = 0; }
    }
    for (; i + 64 <= n; i += 64) this._block(u8, i);
    if (i < n) { this.buf.set(u8.subarray(i), 0); this.bl = n - i; }
  };
  Sha256.prototype.hexOut = function () {
    // длина сообщения в битах, 64-бит BE; файлы < 512 МБ — старшие 32 бита нулевые
    var bits = this.len * 8;
    var pad = this.bl < 56 ? 56 - this.bl : 120 - this.bl;
    var tail = new Uint8Array(pad + 8);
    tail[0] = 0x80;
    // 64-бит BE длина; файлы < 512 МБ — байты pad+0..pad+3 нулевые (Uint8Array)
    tail[pad + 4] = (bits >>> 24) & 0xff;
    tail[pad + 5] = (bits >>> 16) & 0xff;
    tail[pad + 6] = (bits >>> 8) & 0xff;
    tail[pad + 7] = bits & 0xff;
    this.update(tail);
    var out = "";
    for (var j = 0; j < 8; j++) out += ("00000000" + (this.H[j] >>> 0).toString(16)).slice(-8);
    return out;
  };
  Sha256.prototype.save = function () {
    return { h: this.H.slice(), b: Array.prototype.slice.call(this.buf, 0, this.bl), bl: this.bl, len: this.len };
  };
  Sha256.load = function (s) {
    var o = new Sha256();
    if (!s) return o;
    o.H = s.h.slice(); o.buf.set(s.b); o.bl = s.bl; o.len = s.len;
    return o;
  };
  // -- sha256:end

  // ---------- ZIP (STORE): центральный каталог из хвоста, файлы по одному ----------
  function u16(v, o) { return v.getUint16(o, true); }
  function u32(v, o) { return v.getUint32(o, true); }
  function zipEntriesFromBlob(blob) {
    var tailLen = Math.min(blob.size, 2 * 1024 * 1024);
    return blob.slice(blob.size - tailLen).arrayBuffer().then(function (tailBuf) {
      var v = new DataView(tailBuf), n = tailBuf.byteLength, i = n - 22, eocd = -1;
      for (; i >= Math.max(0, n - 66000); i--) {
        if (u32(v, i) === 0x06054b50) { eocd = i; break; }
      }
      if (eocd < 0) throw new Error("ZIP: EOCD не найден");
      var cnt = u16(v, eocd + 10), out = [];
      var cdStart = blob.size - tailLen;            // смещение хвоста в полном файле
      var off = u32(v, eocd + 16) - cdStart;         // каталог в координатах хвоста
      for (var k = 0; k < cnt; k++) {
        if (off < 0 || off + 46 > n || u32(v, off) !== 0x02014b50)
          throw new Error("ZIP: central dir не уместился в хвост");
        var method = u16(v, off + 10), size = u32(v, off + 24),
            nlen = u16(v, off + 28), elen = u16(v, off + 30), clen = u16(v, off + 32),
            lho = u32(v, off + 42),
            name = new TextDecoder().decode(new Uint8Array(tailBuf, off + 46, nlen));
        if (method !== 0) throw new Error("ZIP: только STORE (метод " + method + ", " + name + ")");
        out.push({ name: name, size: size, lho: lho });
        off += 46 + nlen + elen + clen;
      }
      return out;
    });
  }
  // Локальный заголовок читается по месту: 30 фикс-байт + имя+extra.
  function entryBlob(blob, en) {
    return blob.slice(en.lho, en.lho + 30 + 512).arrayBuffer().then(function (hb) {
      var v = new DataView(hb);
      if (u32(v, 0) !== 0x04034b50) throw new Error("ZIP: bad local header (" + en.name + ")");
      var lnlen = u16(v, 26), lexlen = u16(v, 28);
      var dataOff = en.lho + 30 + lnlen + lexlen;
      return new Blob([blob.slice(dataOff, dataOff + en.size)], { type: mimeOf(en.name) });
    });
  }

  // ---------- состояние / события ----------
  var st = {};          // id -> {state:"paused"|"remote", pct, err}
  var man = null;       // manifest.json (встроенный, обогащённый серверным)
  var baked = null;     // baked.json
  var installed = {};   // id -> meta из IDB
  var busy = {};        // id -> {state, pct, ac} — только активная работа
  function dispatch() { try { window.dispatchEvent(new Event("pkgs-changed")); } catch (e) {} }
  function fmtMb(x) { return (x / 1e6).toFixed(x < 1e7 ? 1 : 0); }
  function metaOf(id) {
    if (!man) return null;
    var ps = man.packages || [];
    for (var i = 0; i < ps.length; i++) if (ps[i].id === id) return ps[i];
    return null;
  }

  function stateOf(id) {
    if (busy[id] && busy[id].state) return busy[id].state;
    if (st[id] && st[id].state === "paused") return "paused";
    var m = metaOf(id);
    if (!m || !m.audio) return null;
    if (baked) {
      if (m.type === "asr" && baked.variant === "full") return "baked";
      if (baked.bakedPacks && baked.bakedPacks.indexOf(id) >= 0) return "baked";
      if (m.type === "audio-core" && baked.bakedAudioIds === "all") return "baked";
    }
    if (installed[id] && m.audio.sha256 && installed[id].sha256 &&
        installed[id].sha256 !== m.audio.sha256) {
      // v2.49.4: «обновление» — только когда серверный пак реально НОВЕЕ
      // установленного (сравнение версий). Равные версии при разных sha —
      // доверяем установленному: лечит мигание от вшитого манифеста.
      var iv = installed[id].version, mv = m.version;
      if (iv && mv) return verCmp(mv, iv) > 0 ? "update" : "downloaded";
      return "update";
    }
    return installed[id] ? "downloaded" : "remote";
  }

  // ---------- публичное ----------
  function augment(s0) {
    var items = s0.items || [];
    for (var i = 0; i < items.length; i++) {
      var p = items[i], m = metaOf(p.id);
      if (!m) continue;
      if (m.type === "audio-core" || m.type === "asr") {
        p.dl = true;
        // v2.45.2: подписи у строк-докачек убраны совсем. Даже краткие
        // («1456 слов», «модели») на экране 360dp оставляли заголовку
        // ~120px, и он обрезался («Озвучка б…»); счётчик слов переехал
        // в строку-пояснение группы, справа остаётся только бейдж «↓ МБ».
        p.dlLabel = "";
      }
      var s = stateOf(p.id);
      if (!s || !m.audio) { p.audio = null; continue; }
      var mb = fmtMb(m.audio.size);
      var a = { state: s, sizeMb: mb, pct: 0, label: "", cls: "text-muted-foreground" };
      if (s === "baked") { a.label = "вшито"; a.cls = "text-[#34C759]"; }
      else if (s === "downloaded") { a.label = mb + " МБ ✓"; a.cls = "text-[#34C759]"; }
      else if (s === "downloading") { a.pct = busy[p.id] ? busy[p.id].pct : ((st[p.id] && st[p.id].pct) || 0); a.label = (busy[p.id] ? "" : "авто·") + a.pct + "%"; a.cls = "text-[#007AFF]"; }
      else if (s === "unpacking") { a.label = "распаковка…"; a.cls = "text-[#007AFF]"; }
      else if (s === "paused") { a.pct = st[p.id] ? (st[p.id].pct || 0) : 0; a.label = "пауза · " + a.pct + "%"; a.cls = "text-[#8E8E93]"; }
      else if (s === "update") { a.label = "обновление ↓ " + mb + " МБ"; a.cls = "text-[#FF9500]"; }
      else { a.label = "↓ " + mb + " МБ"; a.cls = "text-[#007AFF]"; }
      p.audio = a;
    }
    return s0;
  }

  function idsFor(id) {
    if (id === "audio-a2b1")
      return fetch("/packages/audio-a2b1.json").then(function (r) { return r.json(); })
        .then(function (j) { return j.ids || []; });
    if (id === "asr-models") return Promise.resolve([]);
    return fetch("/packages/" + id + "/words.json").then(function (r) { return r.json(); })
      .then(function (list) { return (list || []).map(function (w) { return w.id; }); });
  }

  function applyAudio(id) {
    return idsFor(id).then(function (ids) {
      var pre = "/__pkg/" + id;
      for (var i = 0; i < ids.length; i++) {
        window.__pkgAudio[ids[i]] = pre;
        window.__pkgAudio[ids[i] + "_ex"] = pre;
      }
    }).catch(function () {});
  }

  // ---------- частичная загрузка (parts) ----------
  function savePart(id, part) { return pSet("part|" + id, part).catch(function () {}); }
  function clearPart(id) { return pDel("part|" + id).catch(function () {}); }

  // v2.49.4: авто-докачка — сетевой сбой больше не бросает загрузку на паузу
  var MAXRT = 6;
  function autoRetry(id, why) {
    var s = st[id] || (st[id] = {});
    var n = (s.tries || 0) + 1;
    if (n > MAXRT) {
      s.state = "paused"; s.pct = lastPct[id] || s.pct || 0; s.auto = false;
      try { console.warn("[PKGDL] " + id + ": авто-докачка остановлена (" + MAXRT + " попыток): " + why); } catch (e) {}
      dispatch();
      return;
    }
    s.tries = n; s.state = "downloading"; s.pct = lastPct[id] || s.pct || 0; s.auto = true;
    try { console.log("[PKGDL] " + id + ": авто-докачка, попытка " + n + "/" + MAXRT + " (" + why + ")"); } catch (e) {}
    dispatch();
    setTimeout(function () {
      var cur = st[id];
      if (!cur || !cur.auto || busy[id]) return;
      delete st[id];
      download(id);
    }, Math.min(30000, 2500 * n));
  }

  function download(id) {
    if (busy[id]) return;
    var m = metaOf(id);
    if (!m || !m.audio) return;
    var s0 = stateOf(id);
    if (s0 !== "remote" && s0 !== "update" && s0 !== "paused") return;
    delete st[id];
    var bases = [base(), MIRROR_BASE];
    var url = bases[0] + m.audio.zip;
    var ac = new AbortController();
    busy[id] = { state: "downloading", pct: 0, ac: ac };
    dispatch();
    var phase = "download"; // download → unpack → install (для классификации ошибок)

    pGet("part|" + id).then(function (part) {
      var resume = !!(part && part.got > 0 && part.url === url && part.blob);
      // Состояние сессии. acc — zip целиком на текущий момент (браузерный Blob);
      // hash — инкрементальный SHA-256 всех уже полученных байт.
      var acc = resume ? part.blob : new Blob([]);
      var hash = resume ? Sha256.load(part.hashState) : new Sha256();
      var startBytes = acc.size;                 // сколько байт уже было (для Range)
      var total = (resume && part.total) ? part.total : (m.audio.size || 0);
      var pending = [], pendingBytes = 0, lastSave = Date.now();
      if (resume) try { console.log("[PKGDL] " + id + ": resume с байта " + startBytes + " (Range)"); } catch (e) {}

      function mergePending() {
        if (!pending.length) return;
        var add = pending; pending = []; pendingBytes = 0;
        acc = new Blob([acc].concat(add));
      }
      function persistPart() {
        mergePending();
        return savePart(id, {
          blob: acc, got: acc.size, total: total,
          url: url, hashState: hash.save(), at: Date.now(),
        });
      }

      var headers = resume ? { "Range": "bytes=" + startBytes + "-" } : undefined;
      return fetch(url, { headers: headers, signal: ac.signal }).catch(function (e0) {
        // v2.49.4: raw целиком недоступен — пробуем зеркало jsDelivr (CORS, Range)
        if (url === bases[0] + m.audio.zip) {
          url = bases[1] + m.audio.zip;
          acc = new Blob([]); hash = new Sha256(); startBytes = 0; total = m.audio.size || 0;
          return clearPart(id).then(function () { return fetch(url, { signal: ac.signal }); });
        }
        throw e0;
      }).then(function (res) {
        if (resume && res.status !== 206) {
          // 200 (Range не поддержан) или 416 (часть протухла) — начинаем с нуля
          acc = new Blob([]); hash = new Sha256(); startBytes = 0; total = m.audio.size || 0;
          return fetch(url, { signal: ac.signal });
        }
        return res;
      }).then(function (res) {
        if (!res.ok) throw new Error("HTTP " + res.status);
        if (res.status === 206) {
          var cr = res.headers.get("content-range") || "";
          var mm = /^bytes (\d+)-/.exec(cr);
          if (mm && parseInt(mm[1], 10) !== startBytes) {
            // сервер отдал не ту позицию — перезапуск с нуля
            acc = new Blob([]); hash = new Sha256(); startBytes = 0; total = m.audio.size || 0;
            return fetch(url, { signal: ac.signal });
          }
          var cl = +(res.headers.get("content-length") || 0);
          if (cl) total = startBytes + cl;
        } else {
          var cl2 = +(res.headers.get("content-length") || 0);
          total = cl2 || m.audio.size || 0;
        }
        var reader = res.body.getReader();
        function pump() {
          return reader.read().then(function (r) {
            if (r.done) return;
            var u8 = r.value;
            hash.update(u8);
            pending.push(u8); pendingBytes += u8.byteLength;
            var got = startBytes + acc.size + pendingBytes;
            var pct = total ? Math.min(99, Math.round(got * 100 / total)) : 0;
            lastPct[id] = pct;
            if (busy[id] && busy[id].pct !== pct) { busy[id].pct = pct; dispatch(); }
            if (pendingBytes >= 4 * 1024 * 1024 || Date.now() - lastSave > 5000) {
              lastSave = Date.now();
              return Promise.resolve(mergePending()).then(function () {
                return savePart(id, {
                  blob: acc, got: acc.size, total: total,
                  url: url, hashState: hash.save(), at: Date.now(),
                });
              }).then(pump);
            }
            return pump();
          });
        }
        return pump().then(function () {
          busy[id] = { state: "unpacking", pct: 100, ac: ac }; dispatch();
          mergePending();
          var hex = hash.hexOut();
          if (hex !== m.audio.sha256) {
            // v2.49.4 самолечение: содержимое может быть НОВЕЕ манифеста,
            // по которому шла докачка (вшитый/кэш отстали), или РАВНО уже
            // установленному паку — это не ошибка, установка продолжается.
            var alt = null;
            try {
              var cmj = JSON.parse(localStorage.getItem("pkgs_manifest_remote_v1") || "null");
              ((cmj && cmj.packages) || []).forEach(function (pp) {
                if (pp && pp.id === id && pp.audio && pp.audio.sha256 === hex) alt = pp;
              });
            } catch (e) {}
            if (!alt && installed[id] && installed[id].sha256 === hex) {
              alt = { id: id, version: installed[id].version || "",
                audio: { sha256: hex, files: installed[id].files || m.audio.files,
                         size: installed[id].size || m.audio.size } };
            }
            if (alt) { m = alt; }
            else {
              return clearPart(id).then(function () {
                var err = new Error("sha256 не совпал (файл повреждён)");
                err.noResume = true;
                throw err;
              });
            }
          }
          return acc;
        });
      }).then(function (zipBlob) {
        phase = "unpack";
        return clearPart(id).then(function () { return unpack(id, zipBlob); });
      }).then(function () {
        phase = "install";
        var meta = { sha256: m.audio.sha256, files: m.audio.files, size: m.audio.size, version: m.version || "", at: Date.now() };
        return bSet("packs", id, meta).then(function () { installed[id] = meta; });
      }).then(function () {
        delete busy[id];
        if (st[id]) { delete st[id].tries; delete st[id].auto; }
        return applyAudio(id);
      }).then(dispatch).catch(function (e) {
        var msg = String((e && e.message) || e);
        var aborted = e && (e.name === "AbortError" || /abort/i.test(msg));
        delete busy[id];
        try { console.warn("[PKGDL] " + id + " ошибка (" + phase + "): " + msg); } catch (e2) {}
        if (e && e.noResume || phase !== "download" || aborted && acc.size === 0) {
          // файл полный, но битый/не распаковался — докачивать бессмысленно
          st[id] = { state: "remote", err: msg };
          return clearPart(id).then(dispatch);
        }
        if (aborted) {
          mergePending();
          return persistPart().then(function () {
            st[id] = { state: "paused", pct: lastPct[id] || 0 };
            dispatch();
          });
        }
        // сетевой сбой: уже что-то скачано — пауза с возможностью продолжить
        mergePending();
        if (acc.size > 0) {
          return persistPart().then(function () {
            st[id] = { state: "paused", pct: lastPct[id] || 0, err: msg };
            autoRetry(id, msg);
            dispatch();
          });
        }
        st[id] = { state: "remote", err: msg };
        autoRetry(id, msg);
        dispatch();
      });
    });
  }
  var lastPct = {}; // последний процент для бейджа паузы

  // Распаковка: центральный каталог из хвоста Blob, файлы — по одному slice'ом.
  function unpack(id, zipBlob) {
    return zipEntriesFromBlob(zipBlob).then(function (entries) {
      var chain = Promise.resolve();
      entries.forEach(function (en, i) {
        chain = chain.then(function () {
          if (busy[id] && entries.length > 4) {
            var pct = Math.round(i * 100 / entries.length);
            if (busy[id].pct !== pct) { busy[id].pct = pct; dispatch(); }
          }
          return entryBlob(zipBlob, en).then(function (b2) {
            return bSet("blobs", id + "|" + en.name, b2);
          });
        });
      });
      return chain;
    });
  }

  function pause(id) {
    if (busy[id] && busy[id].ac) { try { busy[id].ac.abort(); } catch (e) {} }
  }

  function cancel(id) {
    if (busy[id] && busy[id].ac) { try { busy[id].ac.abort(); } catch (e) {} }
    delete busy[id];
    delete st[id];
    delete lastPct[id];
    return clearPart(id).then(dispatch);
  }

  function remove(id) {
    if (busy[id]) return Promise.resolve();
    return bKeys("blobs").then(function (keys) {
      var pre = id + "|", chain = Promise.resolve();
      keys.forEach(function (k) {
        if (String(k).slice(0, pre.length) === pre) chain = chain.then(function () { return bDel("blobs", k); });
      });
      return chain;
    }).then(function () { return bDel("packs", id); }).then(function () {
      delete installed[id];
      return idsFor(id).then(function (ids) {
        for (var i = 0; i < ids.length; i++) {
          delete window.__pkgAudio[ids[i]];
          delete window.__pkgAudio[ids[i] + "_ex"];
        }
      }).catch(function () {});
    }).then(dispatch);
  }

  function snapshot() {
    var out = {};
    (man && man.packages || []).forEach(function (p) {
      out[p.id] = Object.assign({}, st[p.id] || {}, { state: stateOf(p.id) });
    });
    return out;
  }

  // ---------- серверный манифест с версионированием ----------
  function verCmp(a, b) {
    var pa = String(a || "0").split("."), pb = String(b || "0").split(".");
    for (var i = 0; i < 3; i++) {
      var x = parseInt(pa[i] || "0", 10) || 0, y = parseInt(pb[i] || "0", 10) || 0;
      if (x !== y) return x < y ? -1 : 1;
    }
    return 0;
  }
  function validPkg(p) {
    return p && p.id && p.audio && p.audio.zip && p.audio.sha256 && p.audio.size > 0;
  }
  function mergeManifest(local, remote) {
    if (!remote || !remote.packages || !remote.packages.length) return local;
    var rv = remote.version || remote.packsRepoVer, lv = local.version || local.packsRepoVer;
    if (verCmp(rv, lv) < 0) return local; // сервер старее встроенного — игнор
    var rmap = {}, out = [];
    remote.packages.forEach(function (p) { if (validPkg(p)) rmap[p.id] = p; });
    (local.packages || []).forEach(function (p) {
      out.push(rmap[p.id] || p);
      delete rmap[p.id];
    });
    Object.keys(rmap).forEach(function (k) { out.push(rmap[k]); }); // новые пакеты
    return Object.assign({}, local, remote, { packages: out });
  }
  function fetchRemoteManifest() {
    // v2.49.4: два источника (raw → jsDelivr) + кэш последнего ответа в
    // localStorage. Кэш закрывает главный дефект «оранжевой озвучки»:
    // при сбое сети манифест больше НЕ откатывается к вшитому (там пак
    // старее установленного → ложное «обновление»).
    var urls = [base() + "manifest.json", MIRROR_BASE + "manifest.json"];
    function attempt(k) {
      if (k >= urls.length) return Promise.resolve();
      var ac = new AbortController();
      var t = setTimeout(function () { try { ac.abort(); } catch (e) {} }, 6000);
      return fetch(urls[k], { cache: "no-store", signal: ac.signal })
        .then(function (r) { if (!r.ok) throw new Error("HTTP " + r.status); return r.json(); })
        .then(function (j) {
          clearTimeout(t);
          man = mergeManifest(man, j);
          try { localStorage.setItem("pkgs_manifest_remote_v1", JSON.stringify(j)); } catch (e) {}
          try { if (updCount() > 0) window.dispatchEvent(new Event("pkgs-changed")); } catch (e) {}
          try {
            console.log("[PKGDL] серверный манифест: v" + ((j && (j.version || j.packsRepoVer)) || "?") +
              " → применён (пакетов: " + ((j && j.packages) || []).length + ")");
          } catch (e) {}
        })
        .catch(function () {
          clearTimeout(t);
          return attempt(k + 1);
        });
    }
    return attempt(0);
  }

  function init() {
    // v2.25.8: гейт согласия — до принятия пользовательского соглашения
    // никаких сетевых обращений (манифесты/паки). Повторный init() после
    // принятия (bootPackageDownloads из ConsentGate-детей) всё запускает.
    try {
      var _c = JSON.parse(localStorage.getItem("consent.v1") || "null");
      if (!_c || !_c.accepted) {
        try { console.log("[PKGDL] ожидание согласия — init отложен"); } catch (e) {}
        return;
      }
    } catch (e) { /* нет localStorage — консервативно не качаем */ }
    window.__pkgAudio = window.__pkgAudio || {};
    // Постоянное хранилище: пакеты не вычищаются браузером при нехватке места.
    try {
      if (navigator.storage && navigator.storage.persist) {
        navigator.storage.persist().then(function (granted) {
          try { console.log("[PKGDL] storage.persist:", granted); } catch (e) {}
        }).catch(function () {});
      }
    } catch (e) {}
    var jobs = [
      fetch("/packages/manifest.json", { cache: "no-store" }).then(function (r) { return r.json(); })
        .then(function (j) { man = j; }).catch(function () {}),
      fetch("/packages/baked.json").then(function (r) { return r.json(); })
        .then(function (j) { baked = j; }).catch(function () { baked = null; }),
    ];
    Promise.all(jobs).then(function () {
      try {
        var cm = JSON.parse(localStorage.getItem("pkgs_manifest_remote_v1") || "null");
        if (cm && cm.packages && cm.packages.length) man = mergeManifest(man, cm);
      } catch (e) {}
    }).then(fetchRemoteManifest).then(dispatch);
    db().then(function () { return bKeys("packs"); }).then(function (keys) {
      var chain = Promise.resolve();
      keys.forEach(function (k) {
        chain = chain.then(function () {
          return bGet("packs", k).then(function (meta) { installed[k] = meta; });
        });
      });
      return chain;
    }).then(function () {
      var chain = Promise.resolve();
      Object.keys(installed).forEach(function (id) { chain = chain.then(function () { return applyAudio(id); }); });
      return chain;
    }).then(dispatch).catch(function () {});
    if ("serviceWorker" in navigator) {
      try {
        // v2.28.8: режим SW задаётся при регистрации. В нативном APK
        // (Capacitor) оболочка не кэшируется — файлы локальны, и кэш не
        // должен переживать обновления APK; в браузере/PWA офлайн-оболочка
        // активна. sw.js без параметра считает себя web.
        var swNative = !!(window.Capacitor && window.Capacitor.isNativePlatform && window.Capacitor.isNativePlatform());
        navigator.serviceWorker.register("/sw.js?mode=" + (swNative ? "native" : "web")).catch(function () {});
        // v2.42.0 (М5.1): подтверждение успешной загрузки страницы для
        // hot-бандла — снимает сторож SW (см. public/sw.js, hb-confirm).
        // Страница стартовала = веб-слой жив; идемпотентно, безвредно без hot.
        navigator.serviceWorker.ready.then(function (reg) {
          if (reg && reg.active) reg.active.postMessage({ type: "hb-confirm" });
        }).catch(function () {});
      } catch (e) {}
    }
    return Promise.all(jobs).then(dispatch);
  }

  function updCount() {
    try {
      var s = snapshot(), n = 0;
      for (var k in s) { var v = s[k]; if (v && v.state === "update") n++; }
      return n;
    } catch (e) { return 0; }
  }
  // v2.49.4: вернулись в приложение — продолжаем загрузки, прерванные сетью
  // или паузой WebView (уход с экрана настроек JS не останавливает, а вот
  // сворачивание приложения — да; этот обработчик подхватывает всё заново).
  try {
    document.addEventListener("visibilitychange", function () {
      if (document.visibilityState !== "visible") return;
      Object.keys(st).forEach(function (id) {
        var s = st[id];
        if (!s || busy[id]) return;
        var net = s.state === "downloading" || (s.state === "paused" && s.err);
        if (net || (s.auto && s.state !== "remote")) {
          delete st[id];
          download(id);
        }
      });
    });
  } catch (e) {}

  window.PKGDL = {
    init: init, augment: augment, download: download, pause: pause,
    cancel: cancel, remove: remove, snapshot: snapshot,
    states: function () { return snapshot(); },
    updCount: function () { return updCount(); },
    __sha256: Sha256, // тест-хук (resume-сценарии)
  };
  window.__pkgsUpd = updCount;
  init();
})();
